<?php

namespace App\Services;

use App\Models\AcademicCalendarDate;
use App\Models\BehaviourNotificationLog;
use App\Models\BehaviourNotificationRule;
use App\Models\Demerit;
use App\Models\Intervention;
use App\Models\Student;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;

class BehaviourNotificationEvaluator
{
    /**
     * Evaluate active rules as of $asOf (you’ll usually pass “yesterday” at 8am),
     * create a log row for any threshold newly hit, and return how many logs were created.
     */
    public function evaluateAndLog(Carbon $asOf): int
    {
        $created = 0;

        $rules = BehaviourNotificationRule::query()
            ->where('is_active', true)
            ->orderBy('source')
            ->orderBy('category')
            ->orderBy('threshold')
            ->get();

        foreach ($rules as $rule) {
            // Resolve the date window
            $window = $rule->timeframe === 'term'
                ? $this->resolveTermWindow($asOf)
                : $this->resolveRollingWindow($asOf, (int) ($rule->rolling_days ?? 10));

            if (!$window) {
                continue; // nothing to evaluate (no term or no school days)
            }

            // Count matches per student inside the window
            $perStudentCounts = $this->countsForRule($rule, $window);

            foreach ($perStudentCounts as $studentId => $count) {
                // Only act if this threshold is reached
                if ($count < (int) $rule->threshold) {
                    continue;
                }

                // Only log once per (rule, student, window, threshold)
                if ($this->alreadyLogged($rule->id, $studentId, (int) $rule->threshold, $window, $rule->timeframe)) {
                    continue;
                }

                BehaviourNotificationLog::create([
                    'rule_id'       => $rule->id,
                    'student_id'    => (int) $studentId,

                    // What was counted
                    'source'        => $rule->source,      // 'demerit' | 'intervention'
                    'category'      => $rule->category,    // e.g. 'Uniform', 'Skirt'

                    // Threshold reached
                    'hit_threshold' => (int) $rule->threshold,

                    // Window details
                    'window_type'                 => $rule->timeframe, // 'term' | 'rolling_school_days'
                    'window_start_date'           => $window['start'],
                    'window_end_date'             => $window['end'],
                    'window_term_id'              => $window['term_id'] ?? null,
                    'window_school_days_lookback' => $window['lookback'] ?? null,

                    // Snapshots
                    'source_snapshot' => [
                        'source'   => $rule->source,
                        'category' => $rule->category,
                        'count'    => $count,
                        'as_of'    => $asOf->copy()->startOfDay()->toDateTimeString(),
                        'rule'     => [
                            'id'        => $rule->id,
                            'threshold' => (int) $rule->threshold,
                        ],
                    ],
                    'recipients_snapshot' => [], // to be populated at send time
                ]);

                $created++;
            }
        }

        return $created;
    }

    /**
     * Return [student_id => count] for this rule within the given window.
     * $window = ['start'=>Carbon,'end'=>Carbon,'term_id'?=>int,'lookback'?=>int,'dates'?=>array<Y-m-d>]
     */
    protected function countsForRule(BehaviourNotificationRule $rule, array $window): array
    {
        $source   = $rule->source;     // 'demerit' | 'intervention'
        $category = $rule->category;   // epraise label

        if ($source === 'demerit') {
            $q = Demerit::query()->where('category', $category);
            $this->applyStatusExclusions($q, Demerit::class);
            $this->applyWindowFilter($q, $window, 'date');

            // Optional: constrain to known students (your Demerit.student_id stores epraise record_id)
            $q->whereIn('student_id', Student::query()->pluck('record_id'));

            return $q->selectRaw('student_id, COUNT(*) as c')
                ->groupBy('student_id')
                ->pluck('c', 'student_id')
                ->toArray();
        }

        if ($source === 'intervention') {
            $q = Intervention::query()->where('intervention_type', $category);
            $this->applyStatusExclusions($q, Intervention::class);
            $this->applyWindowFilter($q, $window, 'date_added');

            $q->whereIn('student_id', Student::query()->pluck('record_id'));

            return $q->selectRaw('student_id, COUNT(*) as c')
                ->groupBy('student_id')
                ->pluck('c', 'student_id')
                ->toArray();
        }

        return [];
    }

    /**
     * Exclude locally deleted/partially-deleted rows (we count *local* data only).
     */
    protected function applyStatusExclusions(Builder $q, string $modelClass): void
    {
        $exclude = [];

        if (defined($modelClass . '::STATUS_DELETED')) {
            $exclude[] = constant($modelClass . '::STATUS_DELETED');
        }
        if (defined($modelClass . '::STATUS_PARTIALLY_DELETED')) {
            $exclude[] = constant($modelClass . '::STATUS_PARTIALLY_DELETED');
        }

        if ($exclude) {
            $q->whereNotIn('sync_status', $exclude);
        }
    }

    /**
     * Apply a date window to a query against $dateColumn.
     * If $window has 'dates' (rolling school days), also filter by those exact dates.
     */
    protected function applyWindowFilter(Builder $q, array $window, string $dateColumn): void
    {
        $q->whereDate($dateColumn, '>=', $window['start']->toDateString())
            ->whereDate($dateColumn, '<=', $window['end']->toDateString());

        if (!empty($window['dates']) && is_array($window['dates'])) {
            $q->whereIn($dateColumn, $window['dates']);
        }
    }

    /**
     * Prevent duplicate logs for the same (rule, student, window, threshold).
     */
    protected function alreadyLogged(int $ruleId, int $studentId, int $threshold, array $window, string $timeframe): bool
    {
        $q = BehaviourNotificationLog::query()
            ->where('rule_id', $ruleId)
            ->where('student_id', $studentId)
            ->where('hit_threshold', $threshold)
            ->whereDate('window_start_date', $window['start'])
            ->whereDate('window_end_date', $window['end']);

        if ($timeframe === 'term') {
            $q->where('window_type', 'term')
                ->where('window_term_id', $window['term_id'] ?? null);
        } else {
            $q->where('window_type', 'rolling_school_days')
                ->where('window_school_days_lookback', $window['lookback'] ?? null);
        }

        return $q->exists();
    }

    /**
     * Current term window for $asOf (start/end are school days).
     * Returns ['start'=>Carbon,'end'=>Carbon,'term_id'=>int] or null.
     */
    protected function resolveTermWindow(Carbon $asOf): ?array
    {
        $pivot = AcademicCalendarDate::query()
            ->where('is_school_day', true)
            ->whereDate('date', '<=', $asOf->toDateString())
            ->orderBy('date', 'desc')
            ->first();

        if (!$pivot || !$pivot->term_id) {
            return null;
        }

        $termId = (int) $pivot->term_id;

        $start = AcademicCalendarDate::query()
            ->where('is_school_day', true)
            ->where('term_id', $termId)
            ->orderBy('date', 'asc')
            ->value('date');

        $end = AcademicCalendarDate::query()
            ->where('is_school_day', true)
            ->where('term_id', $termId)
            ->orderBy('date', 'desc')
            ->value('date');

        if (!$start || !$end) {
            return null;
        }

        return [
            'start'   => Carbon::parse($start)->startOfDay(),
            'end'     => Carbon::parse($end)->startOfDay(),
            'term_id' => $termId,
        ];
    }

    /**
     * Last N school days window (including $asOf), plus exact date list.
     * Returns ['start'=>Carbon,'end'=>Carbon,'lookback'=>int,'dates'=>string[]] or null.
     */
    protected function resolveRollingWindow(Carbon $asOf, int $lookback): ?array
    {
        $dates = AcademicCalendarDate::query()
            ->where('is_school_day', true)
            ->whereDate('date', '<=', $asOf->toDateString())
            ->orderBy('date', 'desc')
            ->limit($lookback)
            ->pluck('date')     // Carbon instances (model cast)
            ->filter()
            ->values()
            ->reverse()
            ->values();

        if ($dates->isEmpty()) {
            return null;
        }

        $start = $dates->first()->copy()->startOfDay();
        $end   = $dates->last()->copy()->startOfDay();

        return [
            'start'    => $start,
            'end'      => $end,
            'lookback' => $lookback,
            'dates'    => $dates->map(fn($d) => $d->toDateString())->all(),
        ];
    }
}
